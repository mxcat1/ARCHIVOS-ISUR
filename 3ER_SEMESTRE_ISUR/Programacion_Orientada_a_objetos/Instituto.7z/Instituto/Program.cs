﻿using System;
using System.Collections.Generic;

namespace Cafeteria.Isur {
    class Ambiente {
        string Nombre { get; set; }
        List<Mueble> Mobiliario { get; set; }

    }

    class Cocina:Ambiente {
        List<Utencilio> utencilios { get; set; }
    }
    class Recepcion:Ambiente { }
    class PatioComida { }
    class ServiciosHigienicos { }

    enum TipoUtencilio{
        Ninguno = 0, Metal = 1, Plastico = 2, Madera= 3   }

    class Utencilio {
        TipoUtencilio Tipo  { get; set; } 
    }

    class Vaso:Utencilio
    {       
    }

    class Plato : Utencilio
    {        
    }

    class Cubierto: Utencilio
    {
    }

    class Olla : Utencilio
    {
    }

    class Producto
    {

        DateTime _fechaVence;

        DateTime fechaVence { get { return _fechaVence; }
            set { _fechaVence = value; } }
        //DateTime fechaVence { get; set; }
        string Nombre { get; set; }
    }

    class Sandwich:Producto { }
    class Bebidas:Producto { }
    class Golosinas:Producto { }

    public class Mueble
    {
        string _tipo;
        public Mueble(string tipo) { _tipo = tipo;  }
    }

    public class Cafeteria {
        public string Nombre { get; set; } 
        internal Ambiente[] Ambientes { get; set; }
        public List<Mueble> Mobiliario { get; set; }

        public Cafeteria()
        {
            Nombre = "El Hambre";
            Mobiliario = new List<Mueble>();           
        }

        public Cafeteria(string nombre)
        {
            Nombre = nombre;
            Mobiliario = new List<Mueble>();
        }
        
        public Cafeteria(string nombre, List<Mueble> muebles)
        {
            Nombre = nombre;
            Mobiliario = muebles;
        }

        public Cafeteria(List<Mueble> muebles)
        {
            Mobiliario = muebles;
        }

    }
}

namespace Instituto
{
    class Ambiente {

    }

    class Aula {

    }


    class Program
    {
        static void Main(string[] args)
        {
            Aula L4 = new Aula();

            List<Cafeteria.Isur.Mueble> Muebles = new List<Cafeteria.Isur.Mueble>();

            Muebles.Add(new Cafeteria.Isur.Mueble("Silla"));
            Muebles.Add(new Cafeteria.Isur.Mueble("Silla"));


            Cafeteria.Isur.Cafeteria c = new 
                Cafeteria.Isur.Cafeteria("Nombre", Muebles);

            Cafeteria.Isur.Cafeteria d = new
                            Cafeteria.Isur.Cafeteria("Nombre", new List<Cafeteria.Isur.Mueble>());
            d.Mobiliario.Add(new Cafeteria.Isur.Mueble("Silla"));

        }
    }
}

