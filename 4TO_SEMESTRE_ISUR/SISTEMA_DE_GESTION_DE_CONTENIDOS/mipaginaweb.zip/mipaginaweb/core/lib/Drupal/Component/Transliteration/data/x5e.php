<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'za', 'bi', 'shi', 'bu', 'ding', 'shuai', 'fan', 'nie', 'shi', 'fen', 'pa', 'zhi', 'xi', 'hu', 'dan', 'wei',
  0x10 => 'zhang', 'tang', 'dai', 'mo', 'pei', 'pa', 'tie', 'bo', 'lian', 'zhi', 'zhou', 'bo', 'zhi', 'di', 'mo', 'yi',
  0x20 => 'yi', 'ping', 'qia', 'juan', 'ru', 'shuai', 'dai', 'zheng', 'shui', 'qiao', 'zhen', 'shi', 'qun', 'xi', 'bang', 'dai',
  0x30 => 'gui', 'chou', 'ping', 'zhang', 'san', 'wan', 'dai', 'wei', 'chang', 'sha', 'qi', 'ze', 'guo', 'mao', 'du', 'hou',
  0x40 => 'zheng', 'xu', 'mi', 'wei', 'wo', 'fu', 'yi', 'bang', 'ping', 'die', 'gong', 'pan', 'huang', 'tao', 'mi', 'jia',
  0x50 => 'teng', 'hui', 'zhong', 'shan', 'man', 'mu', 'biao', 'guo', 'ze', 'mu', 'bang', 'zhang', 'jing', 'chan', 'fu', 'zhi',
  0x60 => 'hu', 'fan', 'chuang', 'bi', 'bi', 'zhang', 'mi', 'qiao', 'chan', 'fen', 'meng', 'bang', 'chou', 'mie', 'chu', 'jie',
  0x70 => 'xian', 'lan', 'gan', 'ping', 'nian', 'jian', 'bing', 'bing', 'xing', 'gan', 'yao', 'huan', 'you', 'you', 'ji', 'guang',
  0x80 => 'pi', 'ting', 'ze', 'guang', 'zhuang', 'mo', 'qing', 'bi', 'qin', 'dun', 'chuang', 'gui', 'ya', 'bai', 'jie', 'xu',
  0x90 => 'lu', 'wu', 'zhuang', 'ku', 'ying', 'di', 'pao', 'dian', 'ya', 'miao', 'geng', 'ci', 'fu', 'tong', 'pang', 'fei',
  0xA0 => 'xiang', 'yi', 'zhi', 'tiao', 'zhi', 'xiu', 'du', 'zuo', 'xiao', 'tu', 'gui', 'ku', 'mang', 'ting', 'you', 'bu',
  0xB0 => 'bing', 'cheng', 'lai', 'bi', 'ji', 'an', 'shu', 'kang', 'yong', 'tuo', 'song', 'shu', 'qing', 'yu', 'yu', 'miao',
  0xC0 => 'sou', 'ce', 'xiang', 'fei', 'jiu', 'e', 'gui', 'liu', 'sha', 'lian', 'lang', 'sou', 'zhi', 'pou', 'qing', 'jiu',
  0xD0 => 'jiu', 'jin', 'ao', 'kuo', 'lou', 'yin', 'liao', 'dai', 'lu', 'yi', 'chu', 'chan', 'tu', 'si', 'xin', 'miao',
  0xE0 => 'chang', 'wu', 'fei', 'guang', 'ku', 'kuai', 'bi', 'qiang', 'xie', 'lin', 'lin', 'liao', 'lu', 'ji', 'ying', 'xian',
  0xF0 => 'ting', 'yong', 'li', 'ting', 'yin', 'xun', 'yan', 'ting', 'di', 'pai', 'jian', 'hui', 'nai', 'hui', 'gong', 'nian',
];
